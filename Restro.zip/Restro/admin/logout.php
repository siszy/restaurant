<!DOCTYPE html>
<html>

<head>

    <title>Siszy Restaurant</title>

</head>

<?php
session_start();
unset($_SESSION['admin_id']);
session_destroy();
header("Location: ../../index.php");
exit;
